
# Pong game by David Pollock
# 19/08/2017
# Base code from https://www.youtube.com/watch?v=x_tPvtyB1fY
# Added text for quitting and winning the game.
# Changed the ball colour and speed
# Added middle line

# Importing pygame and time modules

import pygame
import time

# Initializing pygame
pygame.init()

# I defined colours that he didn't
# Colour definitions
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
SILVER = (192, 192, 192)
RED = (255, 0, 0)

# Setting the screen, caption, clock for time and initializing fonts.
SCR_WID, SCR_HEI = 640, 480
screen = pygame.display.set_mode((SCR_WID, SCR_HEI))
pygame.display.set_caption("Pong by Dave")
pygame.font.init()
clock = pygame.time.Clock()
pygame.mouse.set_visible(False)

# Fps of game for 'clock.tick()'
FPS = 60

# Fonts for game if exited by user
# My Work
game_exit_font = pygame.font.Font(None, 64)
game_exit_font = game_exit_font.render("Game Exited by User", 1, WHITE)

# Player 1 attributes


class Player:
    # Starting attributes for player 1
    def __init__(self):
        self.x, self.y = 16, SCR_HEI / 2
        self.speed = 3
        self.padWid, self.padHei = 8, 64
        self.score = 0
        self.scoreFont = pygame.font.Font(None, 64)
        self.winFont = pygame.font.Font(None, 64)

    # Scoreboard and win font for player 1
    def scoring(self):
        scoreBlit = self.scoreFont.render(str(self.score), 1, WHITE)
        screen.blit(scoreBlit, (32, 16))
        winFont = self.winFont.render("Player 1 wins", 1, WHITE)
        if self.score == 10:
            screen.blit(winFont, (190, 200))
            pygame.display.update()
            time.sleep(2)
            pygame.quit()
            exit()

    # Movement of the paddle
    def movement(self):
        keys = pygame.key.get_pressed()
        if keys[pygame.K_w]:
            self.y -= self.speed
        elif keys[pygame.K_s]:
            self.y += self.speed

        if self.y <= 0:
            self.y = 0
        elif self.y >= SCR_HEI - 64:
            self.y = SCR_HEI - 64

    # draw a paddle (rect) to the screen
    def draw(self):
        pygame.draw.rect(screen, (255, 255, 255), (self.x, self.y, self.padWid, self.padHei))


# Player 2 (or enemy) class is exactly the same as the player 1 class.
class Enemy:
    def __init__(self):
        self.x, self.y = SCR_WID - 16, SCR_HEI / 2
        self.speed = 3
        self.padWid, self.padHei = 8, 64
        self.score = 0
        self.scoreFont = pygame.font.Font(None, 64)
        self.winFont = pygame.font.Font(None, 64)

    def scoring(self):
        scoreBlit = self.scoreFont.render(str(self.score), 1, WHITE)
        screen.blit(scoreBlit, (SCR_HEI + 92, 16))
        # My Work
        winFont = self.winFont.render("Player 2 wins", 1, WHITE)
        if self.score == 10:
            screen.blit(winFont, (190, 200))
            pygame.display.update()
            time.sleep(2)
            pygame.quit()
            exit()

    def movement(self):
        keys = pygame.key.get_pressed()
        if keys[pygame.K_UP]:
            self.y -= self.speed
        elif keys[pygame.K_DOWN]:
            self.y += self.speed

        if self.y <= 0:
            self.y = 0
        elif self.y >= SCR_HEI - 64:
            self.y = SCR_HEI - 64

    def draw(self):
        pygame.draw.rect(screen, (255, 255, 255), (self.x, self.y, self.padWid, self.padHei))


# Attributes for ball
class Ball:
    # Starting values for the ball
    def __init__(self):
        # My work
        self.x, self.y = SCR_WID / 2, SCR_HEI / 2
        self.speed_x = 4
        self.speed_y = 4
        self.size = 8

    # Movement and borders.
    def movement(self):
        self.x += self.speed_x
        self.y += self.speed_y

        # wall column
        if self.y <= 0:
            self.speed_y *= -1
        elif self.y >= SCR_HEI - self.size:
            self.speed_y *= -1

        # If ball exceeds the border, 1 is added to a players score.
        if self.x <= 0:
            self.__init__()
            enemy.score += 1
        elif self.x >= SCR_WID - self.size:
            self.__init__()
            self.speed_x = 3
            player.score += 1

        # wall column
        # paddle column
        # player
        for n in range(-self.size, player.padHei):
            if self.y == player.y + n:
                if self.x <= player.x + player.padWid:
                    self.speed_x *= -1
                    break
            n += 1
        # enemy
        for n in range(-self.size, enemy.padHei):
            if self.y == enemy.y + n:
                if self.x >= enemy.x - enemy.padWid:
                    self.speed_x *= -1
                    break
            n += 1
            # paddle column

    def draw(self):
        pygame.draw.rect(screen, RED, (self.x, self.y, 20, 20))


# Making objects or instances of the classes
ball = Ball()
player = Player()
enemy = Enemy()

# Main Loop


def main():
    while True:
        # My work (exit message)
        # Main Event Handling and loop
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                screen.blit(game_exit_font, (100, 200))
                pygame.display.update()
                time.sleep(2)
                pygame.quit()
                quit()

        # Calling class methods using our instances
        ball.movement()
        player.movement()
        enemy.movement()
        # Fill bg with black
        screen.fill(BLACK)
        # Middle line
        pygame.draw.line(screen, SILVER, (320, 0), (320, 480), 2)

        # Drawing score and players to screen
        ball.draw()
        player.draw()
        player.scoring()
        enemy.draw()
        enemy.scoring()
        # Update the display
        pygame.display.update()
        # Set the game to 60 FPS
        clock.tick(FPS)

# My Work
# Run the main game loop
if __name__ == '__main__':
    main()
